# dezloh-apps

Static files for the installable apps of Dezloh shops. **Do not edit by hand.**
The `dezloh-edge` Cloudflare Worker writes `apps/<shop>/manifest.webmanifest` and the app icons here
when a paid shop is created or changes its name, logo, colour or domain.

Turn on GitHub Pages: Settings → Pages → Deploy from a branch → `main` / `/ (root)`.
